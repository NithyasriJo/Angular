import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BuyComponent } from './buy/buy.component';
import { HeaderComponent } from './header/header.component';
import { SearchComponent } from './search/search.component';

const routes: Routes = [
  {
    path:"buy",
    component:BuyComponent,
  },
  {
    path:"rent",
    component:SearchComponent,
  },
  {
    path:"pg",
    component:SearchComponent,
  },
  {
    path:"commercial",
    component:SearchComponent,
  }
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
